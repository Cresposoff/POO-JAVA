package ejerciciosjavaanexo1.Parqueaderos.exceptions;

public class MaximoCamionesException extends Exception {
    public MaximoCamionesException(String message) {
        super(message);
    }
}
