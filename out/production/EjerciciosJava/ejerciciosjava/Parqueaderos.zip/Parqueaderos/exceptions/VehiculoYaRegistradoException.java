package ejerciciosjavaanexo1.Parqueaderos.exceptions;

public class VehiculoYaRegistradoException extends Exception {
    public VehiculoYaRegistradoException(String message) {
        super(message);
    }
}
