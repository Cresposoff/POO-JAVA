package ejerciciosjavaanexo1.Parqueaderos.exceptions;

public class MaximoMotosException extends Exception {
    public MaximoMotosException(String message) {
        super(message);
    }
}
