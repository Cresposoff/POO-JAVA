package ejerciciosjavaanexo1.Parqueaderos.exceptions;

public class GarajeNoEncontradoException extends Exception {
    public GarajeNoEncontradoException(String message) {
        super(message);
    }
}
