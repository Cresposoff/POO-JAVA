package ejerciciosjavaanexo1.Parqueaderos.exceptions;

public class EspaciosInsuficientesException extends Exception {
    public EspaciosInsuficientesException(String message) {
        super(message);
    }
}
